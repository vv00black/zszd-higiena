# Co jest w tej paczce

Trzy pliki dotyczące migracji hostingu strony z Netlify na GitHub Pages (żeby uniknąć limitów darmowego Netlify):

## 1. `instrukcja-github-pages.md`
Pierwsza, podstawowa instrukcja — jak włączyć GitHub Pages, **jeśli już masz** repozytorium na GitHub połączone z kodem aplikacji. (W Twoim przypadku okazało się, że repozytorium jeszcze nie istnieje — więc zacznij od pliku nr 2 poniżej, ten possłuży jako odniesienie do samego kroku włączania Pages).

## 2. `instrukcja-automatyzacja-github.md`
**Główna, kompletna instrukcja** — zacznij od niej. Dwie części:
- Część A: jednorazowe przygotowanie (instalacja Git, założenie repozytorium, pierwsze wgranie plików, włączenie GitHub Pages)
- Część B: jak od tej pory wgrywać nowe wersje — już tylko dwa kliknięcia

## 3. `wyslij-aktualizacje.bat`
Gotowy plik do pobrania i umieszczenia w folderze z kodem aplikacji na Twoim komputerze. Po dwukrotnym kliknięciu sam wysyła nowe zmiany na GitHub (bez okienek do wypełniania, bez wpisywania poleceń).

**Kolejność działania:** otwórz plik nr 2, wykonaj Część A krok po kroku (tam też jest odnośnik, kiedy skorzystać z pliku `.bat`).
