# Automatyczne wgrywanie aplikacji na GitHub (i GitHub Pages)

Ta instrukcja ma dwie części:
- **Część A** — robisz RAZ, ręcznie (około 15 minut)
- **Część B** — od tego momentu, wgrywanie nowej wersji to już tylko **dwukrotne kliknięcie**

---

# CZĘŚĆ A — jednorazowe przygotowanie

## Krok 1: Zainstaluj Git na Windows

1. Wejdź na: **https://git-scm.com/download/win**
2. Pobieranie zacznie się automatycznie (plik `.exe`)
3. Uruchom pobrany plik
4. Klikaj **Next** przez cały instalator, nic nie zmieniając — domyślne ustawienia są w porządku
5. Na końcu kliknij **Install**, potem **Finish**

## Krok 2: Otwórz "Wiersz polecenia" (Command Prompt)

1. Kliknij przycisk **Start** (ikona Windows na dole ekranu)
2. Wpisz: `cmd`
3. Kliknij w wynik **Wiersz polecenia** / **Command Prompt**
4. Otworzy się czarne okienko z tekstem — to jest normalne

## Krok 3: Przedstaw się Gitowi (tylko raz, na zawsze)

Wklej poniższe dwie linijki do czarnego okienka, **jedna po drugiej**, naciskając Enter po każdej. Zamień `Twoje Imie` i `twoj@email.com` na swoje dane (email najlepiej ten sam, co na GitHub):

```
git config --global user.name "Twoje Imie"
git config --global user.email "twoj@email.com"
```

## Krok 4: Załóż puste repozytorium na GitHub

1. Wejdź na **github.com** i zaloguj się
2. W prawym górnym rogu kliknij **+** → **New repository**
3. W polu **Repository name** wpisz np. `zszd-higiena` (bez spacji i polskich znaków)
4. Zostaw zaznaczone **Public**
5. **WAŻNE:** nie zaznaczaj żadnej z opcji "Add a README file" ani innych — repozytorium ma zostać **całkowicie puste**
6. Kliknij zielony przycisk **Create repository**
7. Zobaczysz stronę z instrukcjami i adresem w formie: `https://github.com/twoja-nazwa/zszd-higiena.git` — **skopiuj ten adres**, będzie potrzebny za chwilę

## Krok 5: Pobierz puste repozytorium na dysk

W tym samym czarnym okienku (Wiersz polecenia) wklej poniższe, zamieniając adres na ten skopiowany w Kroku 4:

```
cd Desktop
git clone https://github.com/twoja-nazwa/zszd-higiena.git
```

To utworzy na Twoim Pulpicie folder `zszd-higiena` — **to jest teraz Twój roboczy folder**, w którym zawsze będą aktualne pliki strony.

## Krok 6: Wgraj obecną wersję aplikacji do tego folderu

1. Otwórz folder `zszd-higiena` na Pulpicie (Eksplorator plików)
2. Skopiuj do niego **te same pliki**, które dotąd przeciągałeś na Netlify (`index.html`, `app.js`, `db.js` i resztę) — wklej je **bezpośrednio** do tego folderu, nie do podfolderu

## Krok 7: Wyślij pierwszą wersję na GitHub

Wróć do czarnego okienka i wklej:

```
cd Desktop\zszd-higiena
git add -A
git commit -m "Pierwsza wersja"
git push
```

Przy pierwszym `git push` może pojawić się okienko logowania do GitHub w przeglądarce — zaloguj się, jeśli o to poprosi.

## Krok 8: Włącz GitHub Pages

Dokładnie tak, jak w poprzedniej instrukcji:
1. Na stronie repozytorium na GitHub kliknij **Settings** → **Pages** (w menu po lewej)
2. **Source**: wybierz **Deploy from a branch**
3. **Branch**: wybierz **main**, folder **/ (root)**
4. Kliknij **Save**
5. Poczekaj 1–3 minuty, odśwież stronę — pojawi się Twój nowy, stały adres strony

**Gotowe — Część A wykonujesz tylko ten jeden raz.**

---

# CZĘŚĆ B — od teraz: dwa kliknięcia

Pobierz plik **`wyslij-aktualizacje.bat`** (w załączniku) i **umieść go w folderze `zszd-higiena`** na Pulpicie (tym samym, z Kroku 5).

## Jak wgrywać nową wersję odtąd

1. Gdy dostaniesz ode mnie nową paczkę ZIP — rozpakuj ją
2. Skopiuj pliki ze środka (te same co zawsze: `index.html`, `app.js` itd.) do folderu `zszd-higiena` na Pulpicie, **nadpisując** stare pliki, gdy zapyta
3. Kliknij dwukrotnie na **`wyslij-aktualizacje.bat`**
4. Poczekaj, aż czarne okienko samo się zamknie (albo naciśnij dowolny klawisz, jeśli poprosi)

To wszystko. Strona zaktualizuje się sama w ciągu minuty, bez żadnego limitu i bez Netlify.

---

## Coś nie działa?

Zrób zrzut ekranu tego, co widzisz w czarnym okienku (albo w przeglądarce), i wyślij mi go — sprawdzę dokładnie, na którym kroku coś poszło nie tak.
