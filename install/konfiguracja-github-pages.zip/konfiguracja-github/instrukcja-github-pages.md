# Jak przenieść stronę z Netlify na GitHub Pages

Ta instrukcja jest dla kogoś, kto **nigdy wcześniej tego nie robił**. Zajmie to około 5 minut. Nie musisz nic instalować — wszystko robisz w przeglądarce, na stronie github.com.

Interfejs GitHub jest po angielsku — dokładne nazwy przycisków angielskich podaję w **pogrubieniu**, obok tłumaczenia.

---

## Krok 1: Wejdź na swoje repozytorium na GitHub

1. Otwórz przeglądarkę i wejdź na **github.com**
2. Zaloguj się (jeśli nie jesteś zalogowany)
3. Znajdź i otwórz repozytorium z kodem aplikacji ZSZD (to samo, które jest połączone z Netlify)

---

## Krok 2: Włącz GitHub Pages

1. Na górze strony repozytorium znajdź poziomy pasek z zakładkami: `Code`, `Issues`, `Pull requests`, `Actions`, `Settings`...
2. Kliknij **Settings** (⚙️ Ustawienia) — to ostatnia zakładka po prawej stronie
3. Po lewej stronie pojawi się pionowe menu. Przewiń je w dół i kliknij **Pages**
4. Zobaczysz sekcję **"Build and deployment"**
5. Pod napisem **"Source"** (Źródło) kliknij rozwijaną listę — powinno tam być napisane "None" lub "Deploy from a branch"
6. Wybierz **"Deploy from a branch"**
7. Poniżej pojawi się druga rozwijana lista — **"Branch"**. Wybierz z niej **`main`** (lub `master`, jeśli main nie ma na liście — to zależy jak nazywa się Twoja główna gałąź)
8. Obok gałęzi będzie jeszcze jedna, mała rozwijana lista z folderem — zostaw ją jako **`/ (root)`**
9. Kliknij zielony przycisk **Save** (Zapisz)

---

## Krok 3: Poczekaj chwilę

Po zapisaniu GitHub zacznie publikować Twoją stronę. To trwa zwykle **1–3 minuty**.

1. Odśwież tę samą stronę (Settings → Pages) po chwili
2. Na górze powinien pojawić się zielony pasek z napisem coś w stylu:
   **"Your site is live at https://twoja-nazwa.github.io/nazwa-repozytorium/"**
3. To jest Twój **nowy adres strony** — kliknij w niego, żeby sprawdzić, czy aplikacja działa

---

## Krok 4: Zapisz sobie nowy adres

Nowy adres będzie wyglądał mniej więcej tak:
```
https://twoja-nazwa-uzytkownika.github.io/nazwa-repozytorium/
```

Ten adres **zawsze pozostanie taki sam** (w przeciwieństwie do tych zmieniających się linków testowych z Netlify) — możesz go śmiało zapisać w zakładkach przeglądarki i przekazywać brygadzistom.

---

## Krok 5: Od teraz — nic nie musisz robić inaczej

Dobra wiadomość: **cały dotychczasowy sposób pracy zostaje bez zmian.**

- Nadal wysyłasz zmiany do tego samego repozytorium na GitHub, tak jak dotychczas
- GitHub Pages **sam automatycznie aktualizuje stronę** po każdej zmianie — dokładnie tak, jak robił to Netlify
- Różnica jest tylko taka, że **nie ma już żadnego limitu liczby aktualizacji** — możesz wprowadzać zmiany tak często, jak potrzeba, bez obawy o "zużycie kredytów"

---

## Czy mogę teraz usunąć Netlify?

Możesz, ale **nie musisz się spieszyć**. Obie strony (Netlify i GitHub Pages) mogą na razie działać równolegle — to nic nie kosztuje, dopóki nie wykorzystasz limitu na Netlify. Gdy się upewnisz, że nowy adres z GitHub Pages działa dobrze, możesz po prostu przestać korzystać ze starego linku z Netlify — nie trzeba nic aktywnie "wyłączać" ani usuwać.

---

## Coś poszło nie tak?

Jeśli po kroku 3 nie pojawia się zielony pasek z adresem, albo strona po wejściu w nowy adres wygląda na pustą/zepsutą — zrób zrzut ekranu tego, co widzisz w Settings → Pages, i wyślij mi go. Sprawdzę dokładnie, co się dzieje.
